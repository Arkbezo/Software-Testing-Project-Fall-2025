package dal;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import model.dto.CustomerDTO;
import model.dto.Message;
import model.dto.MessageType;
import model.dto.Response;

public class CustomerSearchECTTest {

    private DALManager dal;
    private Response res;

    @BeforeEach
    void setUp() {
        dal = new DALManager();
        res = new Response();
    }

    // EC2: empty string
    @Test
    void searchCustomers_emptyString_returnsList_noErrors() {
        ArrayList<CustomerDTO> result = dal.searchCustomersByName("", res);

        // If DB connection works, result should be a list (possibly empty)
        assertNotNull(result, "Expected a non-null list when DB connection is available");
        assertTrue(res.isSuccessfull(), "No Error/Exception messages expected");
    }

    // EC4: valid non-existing name -> empty list
    @Test
    void searchCustomers_nonExistingName_returnsEmptyList() {
        ArrayList<CustomerDTO> result = dal.searchCustomersByName("zzzz_non_existing_12345", res);

        assertNotNull(result);
        assertTrue(result.isEmpty(), "Expected no matches for a non-existing name");
        assertTrue(res.isSuccessfull());
    }

    // EC5: special characters -> robustness (should not crash)
    @Test
    void searchCustomers_specialCharacters_noCrash() {
        ArrayList<CustomerDTO> result = dal.searchCustomersByName("@#$%^&*", res);

        // Robustness expectation: no crash.
        // Acceptable outcomes:
        // 1) returns list (possibly empty) and success
        // 2) returns null and records an Exception/Error message
        if (result == null) {
            assertFalse(res.messagesList.isEmpty(), "If result is null, an error/exception message should exist");
            assertFalse(res.isSuccessfull(), "Should be unsuccessful if an exception/error occurred");
        } else {
            assertNotNull(result);
            // may be empty or non-empty depending on DB content
        }
    }

    // EC6: very long string -> robustness
    @Test
    void searchCustomers_veryLongString_noCrash() {
    	StringBuilder sb = new StringBuilder();
    	for (int i = 0; i < 300; i++) {
    	    sb.append("a");
    	}
    	String longName = sb.toString();


        ArrayList<CustomerDTO> result = dal.searchCustomersByName(longName, res);

        // Same robustness expectation
        if (result == null) {
            assertFalse(res.messagesList.isEmpty());
            assertFalse(res.isSuccessfull());
        } else {
            assertNotNull(result);
        }
    }

    // EC1: null input 
    @Test
    void searchCustomers_nullInput_handled() {
        ArrayList<CustomerDTO> result = dal.searchCustomersByName(null, res);

        // SQL string concatenation turns null into "null" inside the query,
        // so often it won't crash and returns list (maybe empty).
        // If it DOES fail (e.g., DBReader rejects it), then it should record error/exception.
        if (result == null) {
            assertFalse(res.messagesList.isEmpty());
            assertFalse(res.isSuccessfull());
        } else {
            assertNotNull(result);
        }
    }

 
}
