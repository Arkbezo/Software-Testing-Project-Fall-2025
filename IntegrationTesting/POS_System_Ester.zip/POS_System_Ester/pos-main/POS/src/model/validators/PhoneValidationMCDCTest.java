package model.validators;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import model.dto.CustomerDTO;
import model.dto.MessageType;
import model.dto.Response;

public class PhoneValidationMCDCTest {

    private Response res;

    @BeforeEach
    void setUp() {
        res = new Response();
    }

    // T1 (MC/DC for A): phoneNumber == null => error
    @Test
    void phoneNumber_null_triggersError() {
        CustomerDTO c = new CustomerDTO();
        c.setName("Ana");
        c.setPhoneNumber(null);

        CommonValidator.validateObject(c, res);

        assertFalse(res.isSuccessfull());
        assertEquals(MessageType.Error, res.messagesList.get(0).type);
    }

    // T2 (MC/DC for B): non-null but length < 10 => error
    @Test
    void phoneNumber_tooShort_triggersError() {
        CustomerDTO c = new CustomerDTO();
        c.setName("Ana");
        c.setPhoneNumber("123456789"); // 9 chars

        CommonValidator.validateObject(c, res);

        assertFalse(res.isSuccessfull());
        assertEquals(MessageType.Error, res.messagesList.get(0).type);
    }

    // T3 (Both false): length == 10 => no error
    @Test
    void phoneNumber_atBoundary_noError() {
        CustomerDTO c = new CustomerDTO();
        c.setName("ValidCustomerName");
        c.setPhoneNumber("1234567890"); // 10 chars

        CommonValidator.validateObject(c, res);

        assertTrue(res.isSuccessfull());
    }
}
