package model.validators;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import model.dto.Message;
import model.dto.MessageType;
import model.dto.Response;
import model.dto.UserDTO;

public class PasswordValidationTest {

    private Response response;

    @BeforeEach
    void setUp() {
        response = new Response();
        response.messagesList.clear();
    }

    // TC-PASS-001: password = null
    @Test
    void testPasswordIsNull() {
        UserDTO user = new UserDTO();
        user.setUsername("validUser");
        user.setPassword(null);
        user.setRole("ADMIN");

        CommonValidator.validateObject(user, response);

        assertEquals(1, response.messagesList.size());

        Message msg = response.messagesList.get(0);
        assertEquals(MessageType.Error, msg.type);
        assertEquals(
            "Password is not valid, provide valid password with at least 3 characters.",
            msg.message
        );
    }

    // TC-PASS-002: password length < 3
    @Test
    void testPasswordTooShort() {
        UserDTO user = new UserDTO();
        user.setUsername("validUser");
        user.setPassword("ab");
        user.setRole("ADMIN");

        CommonValidator.validateObject(user, response);

        assertEquals(1, response.messagesList.size());
        assertEquals(MessageType.Error, response.messagesList.get(0).type);
    }

    // TC-PASS-003: password length == 3 (boundary)
    @Test
    void testPasswordAtBoundary() {
        UserDTO user = new UserDTO();
        user.setUsername("validUser");
        user.setPassword("abc");
        user.setRole("ADMIN");

        CommonValidator.validateObject(user, response);

        assertTrue(response.messagesList.isEmpty());
    }

    // TC-PASS-004: password length > 3
    @Test
    void testPasswordAboveBoundary() {
        UserDTO user = new UserDTO();
        user.setUsername("validUser");
        user.setPassword("abcd");
        user.setRole("ADMIN");

        CommonValidator.validateObject(user, response);

        assertTrue(response.messagesList.isEmpty());
    }

    // TC-PASS-005: nominal valid password
    @Test
    void testPasswordNominalValid() {
        UserDTO user = new UserDTO();
        user.setUsername("validUser");
        user.setPassword("Password123");
        user.setRole("ADMIN");

        CommonValidator.validateObject(user, response);

        assertTrue(response.messagesList.isEmpty());
    }
}
