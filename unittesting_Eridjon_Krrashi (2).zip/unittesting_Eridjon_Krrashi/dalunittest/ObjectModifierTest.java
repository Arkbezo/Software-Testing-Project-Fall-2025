package dalunittest;

import dal.ObjectModifier;
import model.dto.*;
import org.junit.jupiter.api.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class ObjectModifierTest {

    private Connection connection;
    private ObjectModifier modifier;

    @BeforeAll
    void setupDatabase() throws Exception {
        String url = "jdbc:mysql://localhost:3306/pos?useSSL=false&serverTimezone=UTC";
        String username = "root";
        String password = "Ekrrashi23$";

        connection = DriverManager.getConnection(url, username, password);
        modifier = new ObjectModifier();
    }

    @AfterAll
    void closeDatabase() throws Exception {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    @BeforeEach
    void cleanTables() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("SET FOREIGN_KEY_CHECKS=0");
        stmt.executeUpdate("DELETE FROM users");
        stmt.executeUpdate("DELETE FROM customers");
        stmt.executeUpdate("DELETE FROM suppliers");
        stmt.executeUpdate("DELETE FROM employees");
        stmt.executeUpdate("DELETE FROM category");
        stmt.executeUpdate("DELETE FROM products");
        stmt.executeUpdate("SET FOREIGN_KEY_CHECKS=1");
        stmt.close();
    }

    @Test
    void updatePassword_success() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO users(username,password,role) VALUES('testuser','oldpass','admin')");

        UserDTO user = new UserDTO();
        user.setUsername("testuser");
        user.setPassword("newpass");

        Response res = new Response();
        modifier.updatePassword(user, connection, res);

        ResultSet rs = stmt.executeQuery("SELECT password FROM users WHERE username='testuser'");
        assertTrue(rs.next());
        assertEquals("newpass", rs.getString("password"));

        stmt.close();
    }

    @Test
    void updateCustomer_success() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO customers(id,name,phoneNumber) VALUES(1,'Old Name','111')");

        CustomerDTO customer = new CustomerDTO(1, "New Name", "222");
        Response res = new Response();
        modifier.updateCustomer(customer, connection, res);

        ResultSet rs = stmt.executeQuery("SELECT name, phoneNumber FROM customers WHERE id=1");
        assertTrue(rs.next());
        assertEquals("New Name", rs.getString("name"));
        assertEquals("222", rs.getString("phoneNumber"));

        stmt.close();
    }

    @Test
    void updateSupplier_success() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO suppliers(id,name,phoneNumber) VALUES(1,'Old Sup','111')");

        SupplierDTO supplier = new SupplierDTO(1, "New Sup", "222");
        Response res = new Response();
        modifier.updateSupplier(supplier, connection, res);

        ResultSet rs = stmt.executeQuery("SELECT name, phoneNumber FROM suppliers WHERE id=1");
        assertTrue(rs.next());
        assertEquals("New Sup", rs.getString("name"));
        assertEquals("222", rs.getString("phoneNumber"));

        stmt.close();
    }

    @Test
    void updateProduct_success() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO category(id,name) VALUES(1,'Cat1')");
        stmt.executeUpdate("INSERT INTO suppliers(id,name,phoneNumber) VALUES(1,'Sup1','123')");
        stmt.executeUpdate("INSERT INTO products(id,name,barcode,price,stock_quantity,category_id,suppliers_id,quantity_type) VALUES(1,'OldProd','B123',10,5,1,1,'counted')");

        ProductDTO product = new ProductDTO();
        product.setProductId(1);
        product.setProductName("NewProd");
        product.setBarcode("B456");
        product.setPrice(20);
        product.setStockQuantity(10);

        Response res = new Response();
        modifier.updateProduct(product, connection, res);

        ResultSet rs = stmt.executeQuery("SELECT name, barcode, price, stock_quantity FROM products WHERE id=1");
        assertTrue(rs.next());
        assertEquals("NewProd", rs.getString("name"));
        assertEquals("B456", rs.getString("barcode"));
        assertEquals(20, rs.getDouble("price"));
        assertEquals(10, rs.getDouble("stock_quantity"));

        stmt.close();
    }

    @Test
    void updateEmployee_success() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO employees(id,name,phoneNumber) VALUES(1,'Old Emp','111')");

        EmployeeDTO employee = new EmployeeDTO(1, "New Emp", "222");
        Response res = new Response();
        modifier.updateEmployee(employee, connection, res);

        ResultSet rs = stmt.executeQuery("SELECT name, phoneNumber FROM employees WHERE id=1");
        assertTrue(rs.next());
        assertEquals("New Emp", rs.getString("name"));
        assertEquals("222", rs.getString("phoneNumber"));

        stmt.close();
    }

    @Test
    void updateCategory_success() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO category(id,name) VALUES(1,'Old Cat')");

        CategoryDTO category = new CategoryDTO(1, "New Cat");
        Response res = new Response();
        modifier.updateCategory(category, connection, res);

        ResultSet rs = stmt.executeQuery("SELECT name FROM category WHERE id=1");
        assertTrue(rs.next());
        assertEquals("New Cat", rs.getString("name"));

        stmt.close();
    }
}
