package dalunittest;

import dal.ObjectMapper;
import model.dto.*;
import org.junit.jupiter.api.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class ObjectMapperTest {

    private Connection connection;
    private ObjectMapper mapper;

    @BeforeAll
    void setupDatabase() throws Exception {
        String url = "jdbc:mysql://localhost:3306/pos?useSSL=false&serverTimezone=UTC";
        String username = "root";
        String password = "Ekrrashi23$";

        connection = DriverManager.getConnection(url, username, password);
        mapper = new ObjectMapper();
    }

    @AfterAll
    void closeDatabase() throws Exception {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    @BeforeEach
    void cleanTables() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("SET FOREIGN_KEY_CHECKS=0");
        stmt.executeUpdate("DELETE FROM products");
        stmt.executeUpdate("DELETE FROM employees");
        stmt.executeUpdate("DELETE FROM users");
        stmt.executeUpdate("DELETE FROM customers");
        stmt.executeUpdate("DELETE FROM suppliers");
        stmt.executeUpdate("DELETE FROM category");
        stmt.executeUpdate("SET FOREIGN_KEY_CHECKS=1");
        stmt.close();
    }

    @Test
    void verifyUser_validUser_addsSuccessMessage() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO users(username,password,role) VALUES('user1','pass1','admin')");
        ResultSet rs = stmt.executeQuery("SELECT * FROM users WHERE username='user1' AND password='pass1'");
        UserDTO user = new UserDTO();
        Response res = new Response();

        mapper.verifyUser(rs, user, res);

        assertEquals("admin", user.getRole());
        assertEquals(1, res.messagesList.size());
        assertEquals("Successfully Login", res.getInfoMessages());

        stmt.close();
    }

    @Test
    void getUsers_returnsAllUsers() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO users(username,password,role) VALUES('user1','pass1','admin')");
        stmt.executeUpdate("INSERT INTO users(username,password,role) VALUES('user2','pass2','cashier')");

        ResultSet rs = stmt.executeQuery("SELECT * FROM users");
        ArrayList<UserDTO> users = mapper.getUsers(rs);

        assertEquals(2, users.size());
        stmt.close();
    }

    @Test
    void getCustomers_returnsAllCustomers() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO customers(name,phoneNumber) VALUES('John','123')");
        ResultSet rs = stmt.executeQuery("SELECT * FROM customers");

        ArrayList<CustomerDTO> customers = mapper.getCustomers(rs);
        assertEquals(1, customers.size());
        assertEquals("John", customers.get(0).getName());

        stmt.close();
    }

    @Test
    void getSuppliers_returnsAllSuppliers() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO suppliers(name,phoneNumber) VALUES('Sup1','999')");
        ResultSet rs = stmt.executeQuery("SELECT * FROM suppliers");

        ArrayList<SupplierDTO> suppliers = mapper.getSuppliers(rs);
        assertEquals(1, suppliers.size());
        assertEquals("Sup1", suppliers.get(0).getName());

        stmt.close();
    }

    @Test
    void getEmployees_returnsAllEmployees() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO employees(name,phoneNumber) VALUES('Alice','555')");
        ResultSet rs = stmt.executeQuery("SELECT * FROM employees");

        ArrayList<EmployeeDTO> employees = mapper.getEmployees(rs);
        assertEquals(1, employees.size());
        assertEquals("Alice", employees.get(0).getName());

        stmt.close();
    }

    @Test
    void getCategories_returnsAllCategories() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO category(name) VALUES('Electronics')");
        ResultSet rs = stmt.executeQuery("SELECT * FROM category");

        ArrayList<CategoryDTO> categories = mapper.getCategories(rs);
        assertEquals(1, categories.size());
        assertEquals("Electronics", categories.get(0).getName());

        stmt.close();
    }

    @Test
    void getProducts_returnsAllProducts() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO category(name) VALUES('Cat1')");
        stmt.executeUpdate("INSERT INTO suppliers(name,phoneNumber) VALUES('Sup1','111')");

        // Get dynamic IDs
        ResultSet rsCat = stmt.executeQuery("SELECT id FROM category WHERE name='Cat1'");
        rsCat.next();
        int catId = rsCat.getInt(1);
        rsCat.close();

        ResultSet rsSup = stmt.executeQuery("SELECT id FROM suppliers WHERE name='Sup1'");
        rsSup.next();
        int supId = rsSup.getInt(1);
        rsSup.close();

        stmt.executeUpdate("INSERT INTO products(name,barcode,price,stock_quantity,category_id,quantity_type,suppliers_id) " +
                "VALUES('Prod1','B123',10,5," + catId + ",'pcs'," + supId + ")");

        ResultSet rs = stmt.executeQuery("SELECT * FROM products");
        ArrayList<ProductDTO> products = mapper.getProducts(rs);

        assertEquals(1, products.size());
        assertEquals("Prod1", products.get(0).getProductName());

        stmt.close();
    }

    @Test
    void getCategoryByName_returnsCategoryOrNull() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO category(name) VALUES('Cat1')");
        ResultSet rs = stmt.executeQuery("SELECT * FROM category WHERE name='Cat1'");
        CategoryDTO cat = mapper.getCategoryByName(rs);
        assertNotNull(cat);
        assertEquals("Cat1", cat.getName());

        rs = stmt.executeQuery("SELECT * FROM category WHERE name='NoCat'");
        cat = mapper.getCategoryByName(rs);
        assertNull(cat);

        stmt.close();
    }

    @Test
    void getSupplierByName_returnsSupplierOrNull() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO suppliers(name,phoneNumber) VALUES('Sup1','111')");
        ResultSet rs = stmt.executeQuery("SELECT * FROM suppliers WHERE name='Sup1'");
        SupplierDTO sup = mapper.getSupplierByName(rs);
        assertNotNull(sup);
        assertEquals("Sup1", sup.getName());

        rs = stmt.executeQuery("SELECT * FROM suppliers WHERE name='NoSup'");
        sup = mapper.getSupplierByName(rs);
        assertNull(sup);

        stmt.close();
    }

    @Test
    void getProductById_returnsProductOrNull() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO category(name) VALUES('Cat1')");
        stmt.executeUpdate("INSERT INTO suppliers(name,phoneNumber) VALUES('Sup1','111')");

        // Get dynamic IDs
        ResultSet rsCat = stmt.executeQuery("SELECT id FROM category WHERE name='Cat1'");
        rsCat.next();
        int catId = rsCat.getInt(1);
        rsCat.close();

        ResultSet rsSup = stmt.executeQuery("SELECT id FROM suppliers WHERE name='Sup1'");
        rsSup.next();
        int supId = rsSup.getInt(1);
        rsSup.close();

        stmt.executeUpdate("INSERT INTO products(name,barcode,price,stock_quantity,category_id,quantity_type,suppliers_id) " +
                "VALUES('Prod1','B123',10,5," + catId + ",'pcs'," + supId + ")");

        ResultSet rs = stmt.executeQuery("SELECT * FROM products WHERE id=(SELECT MAX(id) FROM products)");
        Response res = new Response();
        ProductDTO prod = mapper.getProductById(rs, res);
        assertNotNull(prod);
        assertEquals("Prod1", prod.getProductName());

        rs = stmt.executeQuery("SELECT * FROM products WHERE id=999999");
        prod = mapper.getProductById(rs, res);
        assertNull(prod);

        stmt.close();
    }

    @Test
    void searchCategoryByName_throwsUnsupportedException() {
        assertThrows(UnsupportedOperationException.class, () -> mapper.searchCategoryByName(null));
    }
}
