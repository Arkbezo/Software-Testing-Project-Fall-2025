package dalunittest;

import dal.ObjectRemover;
import model.dto.*;
import org.junit.jupiter.api.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class ObjectRemoverTest {

    private Connection connection;
    private ObjectRemover remover;

    @BeforeAll
    void setupDatabase() throws Exception {
        String url = "jdbc:mysql://localhost:3306/pos?useSSL=false&serverTimezone=UTC";
        String username = "root";
        String password = "Ekrrashi23$";

        connection = DriverManager.getConnection(url, username, password);
        remover = new ObjectRemover();
    }

    @AfterAll
    void closeDatabase() throws Exception {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    @BeforeEach
    void cleanTables() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("SET FOREIGN_KEY_CHECKS=0");
        stmt.executeUpdate("DELETE FROM users");
        stmt.executeUpdate("DELETE FROM customers");
        stmt.executeUpdate("DELETE FROM suppliers");
        stmt.executeUpdate("DELETE FROM employees");
        stmt.executeUpdate("DELETE FROM products");
        stmt.executeUpdate("DELETE FROM category");
        stmt.executeUpdate("SET FOREIGN_KEY_CHECKS=1");
        stmt.close();
    }

    @Test
    void deleteUser_success() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO users(username,password,role) VALUES('testuser','pass','admin')");

        UserDTO user = new UserDTO();
        user.setUsername("testuser");

        Response res = new Response();
        remover.deleteUser(connection, res, user);

        ResultSet rs = stmt.executeQuery("SELECT * FROM users WHERE username='testuser'");
        assertFalse(rs.next());
        assertEquals("User Deleted successfully.", res.messagesList.get(0).message);

        stmt.close();
    }

    @Test
    void deleteCustomer_success() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO customers(id,name,phoneNumber) VALUES(1,'Cust1','111')");

        CustomerDTO customer = new CustomerDTO(1, "Cust1", "111");
        Response res = new Response();
        remover.deleteCustomer(connection, res, customer);

        ResultSet rs = stmt.executeQuery("SELECT * FROM customers WHERE id=1");
        assertFalse(rs.next());
        assertEquals("Customer Deleted successfully.", res.messagesList.get(0).message);

        stmt.close();
    }

    @Test
    void deleteSupplier_success() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO suppliers(id,name,phoneNumber) VALUES(1,'Sup1','222')");

        SupplierDTO supplier = new SupplierDTO(1, "Sup1", "222");
        Response res = new Response();
        remover.deleteSupplier(connection, res, supplier);

        ResultSet rs = stmt.executeQuery("SELECT * FROM suppliers WHERE id=1");
        assertFalse(rs.next());
        assertEquals("Supplier Deleted successfully.", res.messagesList.get(0).message);

        stmt.close();
    }

    @Test
    void deleteEmployee_success() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO employees(id,name,phoneNumber) VALUES(1,'Emp1','333')");

        EmployeeDTO employee = new EmployeeDTO(1, "Emp1", "333");
        Response res = new Response();
        remover.deleteEmployee(connection, res, employee);

        ResultSet rs = stmt.executeQuery("SELECT * FROM employees WHERE id=1");
        assertFalse(rs.next());
        assertEquals("Employee Deleted successfully.", res.messagesList.get(0).message);

        stmt.close();
    }

    @Test
    void deleteProduct_success() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO category(id,name) VALUES(1,'Cat1')");
        stmt.executeUpdate("INSERT INTO suppliers(id,name,phoneNumber) VALUES(1,'Sup1','123')");
        stmt.executeUpdate("INSERT INTO products(id,name,barcode,price,stock_quantity,category_id,suppliers_id,quantity_type) VALUES(1,'Prod1','B001',10,5,1,1,'counted')");

        ProductDTO product = new ProductDTO();
        product.setProductId(1);

        Response res = new Response();
        remover.deleteProduct(product, connection, res);

        ResultSet rs = stmt.executeQuery("SELECT * FROM products WHERE id=1");
        assertFalse(rs.next());
        assertEquals("Product Deleted successfully.", res.messagesList.get(0).message);

        stmt.close();
    }

    @Test
    void deleteCategory_success() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO category(id,name) VALUES(1,'CatDel')");

        CategoryDTO category = new CategoryDTO(1, "CatDel");
        Response res = new Response();
        remover.deleteCategory(category, connection, res);

        ResultSet rs = stmt.executeQuery("SELECT * FROM category WHERE id=1");
        assertFalse(rs.next());
        assertEquals("Category Deleted successfully.", res.messagesList.get(0).message);

        stmt.close();
    }
}
