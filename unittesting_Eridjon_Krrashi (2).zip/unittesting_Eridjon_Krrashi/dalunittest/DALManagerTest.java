package dalunittest;

import dal.DALManager;
import model.dto.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Order;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class DALManagerTest {

    private DALManager dal;

    @BeforeEach
    void setup() {
        dal = new DALManager();
    }

    /* ===============================
       User Management Tests
       =============================== */

    @Test
    @Order(1)
    void verifyUser_validCredentials() {
        Response res = new Response();
        UserDTO user = new UserDTO();
        user.setUsername("admin");      
        user.setPassword("admin123");   
        dal.verifyUser(user, res);
        assertTrue(res.isSuccessfull(), "Valid credentials should succeed");
    }

    @Test
    void verifyUser_invalidCredentials() {
        Response res = new Response();
        UserDTO user = new UserDTO();
        user.setUsername("nonexistent");
        user.setPassword("wrongpass");
        dal.verifyUser(user, res);
        assertFalse(res.isSuccessfull(), "Invalid credentials should fail");
    }

    @Test
    void verifyUser_nullUser() {
        Response res = new Response();
        dal.verifyUser(null, res);
        assertFalse(res.isSuccessfull(), "Null user should fail");
    }

    @Test
    void getUsers_returnsList() {
        Response res = new Response();
        ArrayList<UserDTO> users = dal.getUsers(res);
        assertNotNull(users, "User list should not be null");
    }

    /* ===============================
       Product Management Tests
       =============================== */

    @Test
    void getProducts_returnsList() {
        Response res = new Response();
        ArrayList<ProductDTO> products = dal.getProducts(res);
        assertNotNull(products, "Product list should not be null");
    }

    @Test
    void addProduct_update_deleteProductFlow() {
        Response res = new Response();
        ProductDTO p = new ProductDTO(
                0, 
                "JUNIT_PRODUCT_" + System.currentTimeMillis(), 
                "JUNIT_BARCODE_" + System.currentTimeMillis(), 
                10.0, 
                5.0, 
                1, 
                "kg"
        );
        p.setSupplierId(1);

        // Add
        dal.addProduct(p, res);
        assertTrue(res.isSuccessfull(), "Product should be added successfully");

        // Retrieve
        Response res2 = new Response();
        ArrayList<ProductDTO> found = dal.searchProductsByName("JUNIT_PRODUCT_", res2);
        assertNotNull(found);
        ProductDTO added = found.get(0);
        assertTrue(added.getProductName().contains("JUNIT_PRODUCT_"));

        // Update
        added.setPrice(20.0);
        Response res3 = new Response();
        dal.updateProduct(added, res3);
        assertTrue(res3.isSuccessfull(), "Product should be updated successfully");

        ProductDTO updated = dal.getProductById(added.getProductId(), new Response());
        assertEquals(20.0, updated.getPrice(), 0.01);

        // Delete
        Response res4 = new Response();
        dal.deleteProduct(updated, res4);
        assertTrue(res4.isSuccessfull(), "Product should be deleted successfully");

        ProductDTO deleted = dal.getProductById(updated.getProductId(), new Response());
        assertNull(deleted, "Deleted product should be null");
    }

    @Test
    void searchProductsByName_variations() {
        Response res = new Response();
        ArrayList<ProductDTO> result;

        result = dal.searchProductsByName(null, res);
        assertNotNull(result);

        result = dal.searchProductsByName("", res);
        assertNotNull(result);

        result = dal.searchProductsByName("@#$%^", res);
        assertNotNull(result);

        String longString = "A".repeat(1000);
        result = dal.searchProductsByName(longString, res);
        assertNotNull(result);
    }

    @Test
    void getProductById_boundaryTests() {
        Response res = new Response();
        assertNull(dal.getProductById(-1, res));
        assertNull(dal.getProductById(0, res));
        ProductDTO p = dal.getProductById(1, res);
        assertTrue(p == null || p.getProductId() == 1);
        assertNull(dal.getProductById(Integer.MAX_VALUE, res));
    }

    /* ===============================
       Customer Management Tests
       =============================== */

    @Test
    void save_update_deleteCustomerFlow() {
        Response res = new Response();
        CustomerDTO c = new CustomerDTO();
        c.setName("JUNIT_CUSTOMER_" + System.currentTimeMillis());

        dal.saveCustomer(c, res);
        assertTrue(res.isSuccessfull(), "Customer should be saved");

        // Update
        c.setName("UPDATED_CUSTOMER_" + System.currentTimeMillis());
        Response res2 = new Response();
        dal.updateCustomer(c, res2);
        assertTrue(res2.isSuccessfull(), "Customer should be updated");

        // Delete
        Response res3 = new Response();
        dal.deleteCustomer(c, res3);
        assertTrue(res3.isSuccessfull(), "Customer should be deleted");
    }

    @Test
    void getCustomers_returnsList() {
        Response res = new Response();
        ArrayList<CustomerDTO> customers = dal.getCustomers(res);
        assertNotNull(customers);
    }

    @Test
    void searchCustomersByName_validName() {
        Response res = new Response();
        ArrayList<CustomerDTO> customers = dal.searchCustomersByName("john", res);
        assertNotNull(customers);
    }

    /* ===============================
       Supplier Management Tests
       =============================== */

    @Test
    void save_update_deleteSupplierFlow() {
        Response res = new Response();
        SupplierDTO s = new SupplierDTO();
        s.setName("JUNIT_SUPPLIER_" + System.currentTimeMillis());

        dal.saveSupplier(s, res);
        assertTrue(res.isSuccessfull(), "Supplier should be saved");

        s.setName("UPDATED_SUPPLIER_" + System.currentTimeMillis());
        Response res2 = new Response();
        dal.updateSupplier(s, res2);
        assertTrue(res2.isSuccessfull(), "Supplier should be updated");

        Response res3 = new Response();
        dal.deleteSupplier(s, res3);
        assertTrue(res3.isSuccessfull(), "Supplier should be deleted");
    }

    @Test
    void getSuppliers_returnsList() {
        Response res = new Response();
        ArrayList<SupplierDTO> suppliers = dal.getSuppliers(res);
        assertNotNull(suppliers);
    }

    /* ===============================
       Category Management Tests
       =============================== */

    @Test
    void save_update_deleteCategoryFlow() {
        Response res = new Response();
        CategoryDTO c = new CategoryDTO();
        c.setName("JUNIT_CATEGORY_" + System.currentTimeMillis());

        dal.saveCategory(c, res);
        assertTrue(res.isSuccessfull(), "Category should be saved");

        c.setName("UPDATED_CATEGORY_" + System.currentTimeMillis());
        Response res2 = new Response();
        dal.updateCategory(c, res2);
        assertTrue(res2.isSuccessfull(), "Category should be updated");

        Response res3 = new Response();
        dal.deleteCategory(c, res3);
        assertTrue(res3.isSuccessfull(), "Category should be deleted");
    }

    @Test
    void getCategories_returnsList() {
        Response res = new Response();
        ArrayList<CategoryDTO> categories = dal.getCategories(res);
        assertNotNull(categories);
    }

    @Test
    void searchCategoryByName_validName() {
        Response res = new Response();
        ArrayList<CategoryDTO> categories = dal.searchCategoryByName("food", res);
        assertNotNull(categories);
    }

    /* ===============================
       Employee Management Tests
       =============================== */

    @Test
    void save_update_deleteEmployeeFlow() {
        Response res = new Response();
        EmployeeDTO e = new EmployeeDTO();
        e.setName("JUNIT_EMPLOYEE_" + System.currentTimeMillis());

        dal.saveEmployee(e, res);
        assertTrue(res.isSuccessfull(), "Employee should be saved");

        e.setName("UPDATED_EMPLOYEE_" + System.currentTimeMillis());
        Response res2 = new Response();
        dal.updateEmployee(e, res2);
        assertTrue(res2.isSuccessfull(), "Employee should be updated");

        Response res3 = new Response();
        dal.deleteEmployee(e, res3);
        assertTrue(res3.isSuccessfull(), "Employee should be deleted");
    }

    @Test
    void getEmployees_returnsList() {
        Response res = new Response();
        ArrayList<EmployeeDTO> employees = dal.getEmployees(res);
        assertNotNull(employees);
    }
}
