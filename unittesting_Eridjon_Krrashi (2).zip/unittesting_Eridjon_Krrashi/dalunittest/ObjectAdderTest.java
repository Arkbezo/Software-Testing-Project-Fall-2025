package dalunittest;

import dal.ObjectAdder;
import model.dto.*;
import org.junit.jupiter.api.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class ObjectAdderTest {

    private Connection connection;
    private ObjectAdder objectAdder;

    @BeforeAll
    void setupDatabase() throws Exception {
        String url = "jdbc:mysql://localhost:3306/pos?useSSL=false&serverTimezone=UTC";
        String username = "root";
        String password = "Ekrrashi23$";

        connection = DriverManager.getConnection(url, username, password);
        objectAdder = new ObjectAdder();
    }

    @AfterAll
    void closeDatabase() throws Exception {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    @BeforeEach
    void cleanTables() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("SET FOREIGN_KEY_CHECKS=0");
        stmt.executeUpdate("DELETE FROM products");
        stmt.executeUpdate("DELETE FROM employees");
        stmt.executeUpdate("DELETE FROM users");
        stmt.executeUpdate("DELETE FROM customers");
        stmt.executeUpdate("DELETE FROM suppliers");
        stmt.executeUpdate("DELETE FROM category");
        stmt.executeUpdate("SET FOREIGN_KEY_CHECKS=1");
        stmt.close();
    }

    @Test
    void addUser_works() {
        UserDTO user = new UserDTO();
        user.setUsername("testuser");
        user.setPassword("testpass");
        user.setRole("admin");

        Response res = new Response();
        objectAdder.addUser(user, connection, res);

        assertEquals(1, res.messagesList.size());
        assertEquals("User added successfully.", res.getInfoMessages());
    }

    @Test
    void addUsers_batchInsert_works() {
        ArrayList<UserDTO> users = new ArrayList<>();
        for (int i = 1; i <= 3; i++) {
            UserDTO u = new UserDTO();
            u.setUsername("batchUser" + i);
            u.setPassword("pass" + i);
            u.setRole("user");
            users.add(u);
        }

        Response res = new Response();
        objectAdder.addUsers(users, connection, res);

        // Verify database contains all 3 users
        try {
            ResultSet rs = connection.createStatement()
                    .executeQuery("SELECT COUNT(*) FROM users WHERE username LIKE 'batchUser%'");
            rs.next();
            int count = rs.getInt(1);
            assertEquals(3, count);
            rs.close();
        } catch (Exception e) {
            fail("Exception while verifying batch insert: " + e.getMessage());
        }
    }

    @Test
    void addCustomer_works() {
        CustomerDTO c = new CustomerDTO();
        c.setName("JUnit Customer");
        c.setPhoneNumber("123456");

        Response res = new Response();
        objectAdder.addCustomer(c, connection, res);

        assertEquals(1, res.messagesList.size());
        assertEquals("Customer added successfully.", res.getInfoMessages());
    }

    @Test
    void addSupplier_works() {
        SupplierDTO s = new SupplierDTO();
        s.setName("JUnit Supplier");
        s.setPhoneNumber("999999");

        Response res = new Response();
        objectAdder.addSupplier(s, connection, res);

        assertEquals(1, res.messagesList.size());
        assertEquals("Supplier added successfully.", res.getInfoMessages());
    }

    @Test
    void saveEmployee_works() {
        EmployeeDTO emp = new EmployeeDTO();
        emp.setName("JUnit Employee");
        emp.setPhoneNumber("555555");

        Response res = new Response();
        objectAdder.saveEmployee(emp, connection, res);

        assertEquals(1, res.messagesList.size());
        assertEquals("Supplier added successfully.", res.getInfoMessages());
    }

    @Test
    void saveCategory_works() {
        CategoryDTO c = new CategoryDTO();
        c.setName("JUnit Category");

        Response res = new Response();
        objectAdder.saveCategory(c, connection, res);

        assertEquals(1, res.messagesList.size());
        assertEquals("Category added successfully.", res.getInfoMessages());
    }

    @Test
    void addProduct_works() throws Exception {
        Statement stmt = connection.createStatement();
        stmt.executeUpdate("INSERT INTO category(name) VALUES ('Electronics')");
        stmt.executeUpdate("INSERT INTO suppliers(name, phoneNumber) VALUES ('S1','111')");
        stmt.close();

        int categoryId = 0;
        int supplierId = 0;
        ResultSet rs = connection.createStatement()
                .executeQuery("SELECT id FROM category WHERE name='Electronics'");
        if (rs.next()) categoryId = rs.getInt(1);
        rs.close();

        rs = connection.createStatement()
                .executeQuery("SELECT id FROM suppliers WHERE name='S1'");
        if (rs.next()) supplierId = rs.getInt(1);
        rs.close();

        ProductDTO p = new ProductDTO();
        p.setProductName("JUnit Product");
        p.setBarcode("BAR123");
        p.setPrice(10);
        p.setStockQuantity(5);
        p.setCategoryId(categoryId);
        p.setQuantityType("pcs");
        p.setSupplierId(supplierId);

        Response res = new Response();
        objectAdder.addProduct(p, connection, res);

        assertEquals(1, res.messagesList.size());
        assertEquals("Product added successfully.", res.getInfoMessages());
    }
}
