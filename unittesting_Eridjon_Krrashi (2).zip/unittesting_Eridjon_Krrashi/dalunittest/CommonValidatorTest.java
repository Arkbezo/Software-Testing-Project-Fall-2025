package dalunittest;

import model.dto.*;
import model.validators.CommonValidator;

import org.junit.jupiter.api.*;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class CommonValidatorTest {

    private Response response;

    @BeforeEach
    void setup() {
        response = new Response();
    }

    @Test
    void validateUser_validUser_noErrors() {
        UserDTO user = new UserDTO();
        user.setUsername("validUser");
        user.setPassword("validPass");

        CommonValidator.validateObject(user, response);

        assertEquals(0, response.messagesList.size());
    }

    @Test
    void validateUser_shortUsername_error() {
        UserDTO user = new UserDTO();
        user.setUsername("usr");
        user.setPassword("validPass");

        CommonValidator.validateObject(user, response);

        assertEquals(1, response.messagesList.size());
        assertEquals("Email is not valid, provide valid username with at least 6 characters.", response.messagesList.get(0).message);
    }

    @Test
    void validateUser_shortPassword_error() {
        UserDTO user = new UserDTO();
        user.setUsername("validUser");
        user.setPassword("pw");

        CommonValidator.validateObject(user, response);

        assertEquals(1, response.messagesList.size());
        assertEquals("Password is not valid, provide valid password with at least 3 characters.", response.messagesList.get(0).message);
    }

    @Test
    void validateCustomer_validCustomer_noErrors() {
        CustomerDTO customer = new CustomerDTO();
        customer.setName("Customer1");
        customer.setPhoneNumber("1234567890");

        CommonValidator.validateObject(customer, response);

        assertEquals(0, response.messagesList.size());
    }

    @Test
    void validateCustomer_invalidNameAndPhone_error() {
        CustomerDTO customer = new CustomerDTO();
        customer.setName("Cust"); // too short
        customer.setPhoneNumber("12345"); // too short

        CommonValidator.validateObject(customer, response);

        assertEquals(2, response.messagesList.size());
        assertEquals("Name is not valid, provide valid name with at least 6 characters.", response.messagesList.get(0).message);
        assertEquals("Phone Number is not valid, provide valid Phone Number with at least 10 characters.", response.messagesList.get(1).message);
    }

    @Test
    void validateSupplier_validSupplier_noErrors() {
        SupplierDTO supplier = new SupplierDTO();
        supplier.setName("Supplier1");
        supplier.setPhoneNumber("0987654321");

        CommonValidator.validateObject(supplier, response);

        assertEquals(0, response.messagesList.size());
    }

    @Test
    void validateSupplier_invalidNameAndPhone_error() {
        SupplierDTO supplier = new SupplierDTO();
        supplier.setName("Sup"); // too short
        supplier.setPhoneNumber("1234"); // too short

        CommonValidator.validateObject(supplier, response);

        assertEquals(2, response.messagesList.size());
        assertEquals("Name is not valid, provide valid name with at least 6 characters.", response.messagesList.get(0).message);
        assertEquals("Phone Number is not valid, provide valid Phone Number with at least 10 characters.", response.messagesList.get(1).message);
    }

    @Test
    void validateUsers_batchValidation() {
        ArrayList<UserDTO> users = new ArrayList<>();

        UserDTO u1 = new UserDTO();
        u1.setUsername("usr"); // invalid
        u1.setPassword("pw"); // invalid

        UserDTO u2 = new UserDTO();
        u2.setUsername("validUser");
        u2.setPassword("validPass");

        users.add(u1);
        users.add(u2);

        CommonValidator.validateUsers(users, response);

        assertEquals(2, response.messagesList.size());
        assertEquals("Email is not valid, provide valid username with at least 6 characters.", response.messagesList.get(0).message);
        assertEquals("Password is not valid, provide valid password with at least 3 characters.", response.messagesList.get(1).message);
    }
}
